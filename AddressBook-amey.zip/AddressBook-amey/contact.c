#include "contact.h"

void listContacts(AddressBook *addressBook) 
{
    if (addressBook->contactCount == 0) {
        printf("No contacts in the address book.\n");
        return;
    }
    
    printf("List of Contacts:\n");
    for (int i = 0; i < addressBook->contactCount; i++) {
        printf("Contact %d:\n", i + 1);
        printf("  Name: %s\n", addressBook->contacts[i].name);
        printf("  Phone: %s\n", addressBook->contacts[i].phone);
        printf("  Email: %s\n", addressBook->contacts[i].email);
    }
}

void initialize(AddressBook *addressBook) 
{
    FILE *file;
    file = fopen("contacts.txt", "r");
    if (file == NULL) 
    {
        printf("Error: Unable to open contact.txt\n");
        return;
    }

    addressBook->contactCount = 0;

    // Temporary buffer for reading lines
    char temp[100]; 
    while (fgets(temp, sizeof(temp), file)) 
    {
        // Tokenize the line and store it in the AddressBook
        char *name = strtok(temp, ",");
        char *phone = strtok(NULL, ",");
        char *email = strtok(NULL, "\n");

        if (name && phone && email) 
        {
            strcpy(addressBook->contacts[addressBook->contactCount].name, name);
            strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
            strcpy(addressBook->contacts[addressBook->contactCount].email, email);
            addressBook->contactCount++;
        }

        if (addressBook->contactCount >= MAX_CONTACTS) 
        {
            printf("Warning: Maximum number of contacts reached.\n");
            break;
        }
    }

    fclose(file);
    printf("Contacts loaded successfully.\n");
}

void createContact(AddressBook *addressBook) 
{
    if (addressBook->contactCount >= MAX_CONTACTS) 
    {
        printf("Contact list is full.\n");
        return;
    }

    char name[50], phone[20], email[50];
    int i;

    // Read name
    printf("Enter name: ");
    scanf("%s", name);

    // Check if name is already present
    for (i = 0; i < addressBook->contactCount; i++) 
    {
        if (strcmp(addressBook->contacts[i].name, name) == 0) 
        {
            printf("Name already exists.\n");
            return;
        }
    }

    // Read phone number and validate
    printf("Enter phone number: ");
    scanf("%s", phone);

    if (strlen(phone) != 10 || strspn(phone, "0123456789") != strlen(phone)) 
    {
        printf("Invalid phone number.\n");
        return;
    }

    // Check if phone number is already present
    for (i = 0; i < addressBook->contactCount; i++) 
    {
        if (strcmp(addressBook->contacts[i].phone, phone) == 0) 
        {
            printf("Phone number already exists.\n");
            return;
        }
    }

    // Read email
    printf("Enter email ID: ");
    scanf("%s", email);

    // Validate email
    if (strchr(email, '@') == NULL || strstr(email, ".com") == NULL) 
    {
        printf("Invalid email ID.\n");
        return;
    }

    // Check if email is already present
    for (i = 0; i < addressBook->contactCount; i++) 
    {
        if (strcmp(addressBook->contacts[i].email, email) == 0) 
        {
            printf("Email ID already exists.\n");
            return;
        }
    }

    // Store contact details
    strcpy(addressBook->contacts[addressBook->contactCount].name, name);
    strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
    strcpy(addressBook->contacts[addressBook->contactCount].email, email);

    // Increment contact count
    addressBook->contactCount++;
    printf("Contact added successfully.\n");
}

void searchContact(AddressBook *addressBook) 
{
        int searchOption;
        char searchInput[50];
        int found;
        do {
                printf("Search contact by: \n");
                printf("1. Name\n");
                printf("2. Phone\n");
                printf("3. Email\n");
                printf("Enter your choice: ");
                scanf("%d", &searchOption);
                switch (searchOption)
                {
                        case 1:
                                printf("Enter name to search: ");
                                break;
                        case 2:
                                printf("Enter phone number to search: ");
                                break;
                        case 3:
                                printf("Enter email ID to search: ");
                                break;
                        default:
                                printf("Invalid option! please try again.\n");
                                continue;
                }
                scanf("%49s", searchInput);
                found = 0;
                 for (int i = 0; i < addressBook->contactCount; i++)
                {
                        int match = 0;
                        if(searchOption == 1 && strstr(addressBook->contacts[i].name, searchInput))
                        {
                            match=1;
                        }
                        else if(searchOption == 2 && strstr(addressBook->contacts[i].phone, searchInput))
                        {
                            match=1;
                        }
                        else if(searchOption == 3 && strstr(addressBook->contacts[i].email, searchInput))
                        {
                            match=1;
                        }
                        if (match)
                        {
                            printf("Contact found:\n Name %s,phone: %s,Email: %s\n",
                                            addressBook->contacts[i].name,
                                            addressBook->contacts[i].phone,
                                            addressBook->contacts[i].email);
                            found=1;
                        }
                }
                if(!found)
                {
                    printf("Contact not found.\n");
                }
        }while (!found);
}

void editContact(AddressBook *addressBook) 
{
    if (addressBook->contactCount == 0) 
    {
        printf("No contacts available to edit.\n");
        return;
    }

    int searchOption, i, found = -1;
    char searchValue[50];

    // Give menu for searching the contact
    printf("Search to edit contact by:\n");
    printf("1. Name\n");
    printf("2. Phone\n");
    printf("3. Email\n");
    printf("Enter your choice: ");
    scanf("%d", &searchOption);

    // Read the value to search
    switch (searchOption) 
    {
        case 1:
            printf("Enter name to search: ");
            scanf("%s", searchValue);
            for (i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcmp(addressBook->contacts[i].name, searchValue) == 0) 
                {
                    found = i;
                    break;
                }
            }
            break;

        case 2:
            printf("Enter phone to search: ");
            scanf("%s", searchValue);
            for (i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcmp(addressBook->contacts[i].phone, searchValue) == 0) 
                {
                    found = i;
                    break;
                }
            }
            break;

        case 3:
            printf("Enter email to search: ");
            scanf("%s", searchValue);
            for (i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcmp(addressBook->contacts[i].email, searchValue) == 0) 
                {
                    found = i;
                    break;
                }
            }
            break;

        default:
            printf("Invalid choice.\n");
            return;
    }

    // If contact is not found
    if (found == -1) 
    {
        printf("Contact not found.\n");
        return;
    }

    // Edit the contact
    int editOption;
    printf("What do you want to edit?\n");
    printf("1. Name\n");
    printf("2. Phone\n");
    printf("3. Email\n");
    printf("Enter your choice: ");
    scanf("%d", &editOption);

    switch (editOption) 
    {
        case 1: 
        {
            char newName[50];
            printf("Enter new name: ");
            scanf("%s", newName);

            // Check if name already exists
            for (i = 0; i < addressBook->contactCount; i++) 
            {
                if (i != found && strcmp(addressBook->contacts[i].name, newName) == 0) 
                {
                    printf("Name already exists.\n");
                    return;
                }
            }
            strcpy(addressBook->contacts[found].name, newName);
            printf("Name updated successfully.\n");
            break;
        }
        case 2: 
        {
            char newPhone[20];
            printf("Enter new phone: ");
            scanf("%s", newPhone);

            // Validate phone
            if (strlen(newPhone) != 10 || strspn(newPhone, "0123456789") != strlen(newPhone)) 
            {
                printf("Invalid phone number.\n");
                return;
            }

            // Check if phone already exists
            for (i = 0; i < addressBook->contactCount; i++) 
            {
                if (i != found && strcmp(addressBook->contacts[i].phone, newPhone) == 0) 
                {
                    printf("Phone number already exists.\n");
                    return;
                }
            }
            strcpy(addressBook->contacts[found].phone, newPhone);
            printf("Phone updated successfully.\n");
            break;
        }
        case 3: 
        {
            char newEmail[50];
            printf("Enter new email: ");
            scanf("%s", newEmail);

            // Validate email
            if (strchr(newEmail, '@') == NULL || strstr(newEmail, ".com") == NULL) 
            {
                printf("Invalid email format.\n");
                return;
            }

            // Check if email already exists
            for (i = 0; i < addressBook->contactCount; i++) 
            {
                if (i != found && strcmp(addressBook->contacts[i].email, newEmail) == 0) 
                {
                    printf("Email already exists.\n");
                    return;
                }
            }
            strcpy(addressBook->contacts[found].email, newEmail);
            printf("Email updated successfully.\n");
            break;
        }
        default:
            printf("Invalid choice.\n");
            return;
    }
}

void deleteContact(AddressBook *addressBook) 
{
    if (addressBook->contactCount == 0) 
    {
        printf("No contacts available to delete.\n");
        return;
    }

    int searchOption, i, found = -1;
    char searchValue[50];

    // Give menu for searching the contact
    printf("Search to delete contact by: \n");
    printf("1. Name\n");
    printf("2. Phone\n");
    printf("3. Email\n");
    printf("Enter your choice: ");
    scanf("%d", &searchOption);

    // Read the value to search
    switch (searchOption) 
    {
        case 1:
            printf("Enter name to delete: ");
            scanf("%s", searchValue);
            for (i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcmp(addressBook->contacts[i].name, searchValue) == 0) 
                {
                    found = i;
                    break;
                }
            }
            break;

        case 2:
            printf("Enter phone to delete: ");
            scanf("%s", searchValue);
            for (i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcmp(addressBook->contacts[i].phone, searchValue) == 0) 
                {
                    found = i;
                    break;
                }
            }
            break;

        case 3:
            printf("Enter email to delete: ");
            scanf("%s", searchValue);
            for (i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcmp(addressBook->contacts[i].email, searchValue) == 0) 
                {
                    found = i;
                    break;
                }
            }
            break;

        default:
            printf("Invalid choice.\n");
            return;
    }

    // If contact is not found
    if (found == -1) 
    {
        printf("Contact not found.\n");
        return;
    }

    // Shift contacts to delete the selected one
    for (i = found; i < addressBook->contactCount - 1; i++) 
    {
        addressBook->contacts[i] = addressBook->contacts[i + 1];
    }

    // Decrease contact count
    addressBook->contactCount--;

    printf("Contact deleted successfully.\n");
}

void saveContact(AddressBook *addressBook)
{
    if (addressBook->contactCount == 0) {
        printf("No contacts to save.\n");
        return;
    }

    FILE *file = fopen("contacts.txt", "w");
    if (file == NULL) {
        printf("Error: Unable to open file for saving contacts.\n");
        return;
    }

    // Loop through all contacts and write them to the file
    for (int i = 0; i < addressBook->contactCount; i++) 
    {
        fprintf(file, "%s,%s,%s\n", 
                addressBook->contacts[i].name, 
                addressBook->contacts[i].phone, 
                addressBook->contacts[i].email);
    }

    fclose(file);
    printf("Contacts saved successfully to 'contacts.txt'.\n");
}
