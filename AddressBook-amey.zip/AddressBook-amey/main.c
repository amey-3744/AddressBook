/*==================================
Name: Amey Gunde
Date: 21/11/24
Description: Address Book
==================================*/ 

#include<stdio.h>
#include "contact.h"

void main()
{
    AddressBook addressbook;
    initialize(&addressbook);
    printf("Address book is initialized with %d contacts \n", addressbook.contactCount);
    
    while (1)
    {
        int choice;
        printf("\n");
        printf("\t***AddressBook Menu***");
        printf("\n");
        printf("1. Add contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List contact\n");
        printf("6. Save contact\n");
        printf("7. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                createContact(&addressbook);
                break;
            case 2:
                searchContact(&addressbook);
                break;
            case 3:
                editContact(&addressbook);
                break;
            case 4:
                deleteContact(&addressbook);
                break;
            case 5:
                listContacts(&addressbook);
                break;
            case 6:
                saveContact(&addressbook);
                break;
            case 7:
                printf("Exit\n");
                break;
        }
    }
}

